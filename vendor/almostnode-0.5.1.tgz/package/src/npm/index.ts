/**
 * npm Package Manager
 * Orchestrates package installation into the virtual file system
 */

import { VirtualFS } from '../virtual-fs';
import { Registry, RegistryOptions } from './registry';
import {
  resolveDependencies,
  resolveFromPackageJson,
  ResolvedPackage,
  ResolveOptions,
} from './resolver';
import { downloadAndExtract, extractTarball } from './tarball';
import * as path from '../shims/path';
import { initTransformer, transformPackage, isTransformerReady } from '../transform';
import { assertViteSupported } from '../vite-version';
import type { PackageJson } from '../types/package-json';

/**
 * Normalize a package.json bin field into a consistent Record<string, string>.
 * Handles both string form ("bin": "cli.js") and object form ("bin": {"cmd": "cli.js"}).
 */
function normalizeBin(pkgName: string, bin?: Record<string, string> | string): Record<string, string> {
  if (!bin) return {};
  if (typeof bin === 'string') {
    // String form uses the package name (without scope) as the command name
    const cmdName = pkgName.includes('/') ? pkgName.split('/').pop()! : pkgName;
    return { [cmdName]: bin };
  }
  return bin;
}

/**
 * Resolve an exports/imports condition value to a file path string.
 * Handles both the string form ("condition": "./x.js") and the nested-object
 * form ("condition": { "default": "./x.js" }).
 */
function resolveConditionString(cond: unknown): string | undefined {
  if (typeof cond === 'string') return cond;
  if (cond && typeof cond === 'object') {
    const o = cond as Record<string, unknown>;
    if (typeof o.default === 'string') return o.default;
    if (typeof o.import === 'string') return o.import;
    if (typeof o.require === 'string') return o.require;
  }
  return undefined;
}

/**
 * A "dual" package ships separate ESM and CJS entry points (e.g. birpc's
 * `dist/index.mjs` + `dist/index.cjs`). For these we must NOT transform the ESM
 * entry to CJS at install time: `require()` already resolves the CJS entry via
 * `exports.require`/`main`, while Vite's dep optimizer needs the original ESM
 * source to detect `needsInterop` correctly (transforming it to CJS makes Vite
 * rewrite named imports into a default import that the pre-bundle lacks).
 */
export function isDualPackage(pkgJson: PackageJson): boolean {
  const exp = pkgJson.exports;
  if (exp && typeof exp === 'object' && !Array.isArray(exp)) {
    const exportsObj = exp as Record<string, unknown>;
    const dot = exportsObj['.'];
    const entry = dot && typeof dot === 'object' ? dot : exp;
    if (entry && typeof entry === 'object' && !Array.isArray(entry)) {
      const im = resolveConditionString((entry as Record<string, unknown>).import);
      const req = resolveConditionString((entry as Record<string, unknown>).require);
      if (im && req && im !== req) return true;
    }
  }
  if (typeof pkgJson.module === 'string' && typeof pkgJson.main === 'string' && pkgJson.module !== pkgJson.main) {
    return true;
  }
  return false;
}

export interface InstallOptions {
  registry?: string;
  save?: boolean;
  saveDev?: boolean;
  includeDev?: boolean;
  includeOptional?: boolean;
  onProgress?: (message: string) => void;
  /** Transform ESM packages to CJS after install (default: true) */
  transform?: boolean;
}

export interface InstallResult {
  installed: Map<string, ResolvedPackage>;
  added: string[];
}

/**
 * npm Package Manager for VirtualFS
 */
export class PackageManager {
  private vfs: VirtualFS;
  private registry: Registry;
  private cwd: string;

  constructor(vfs: VirtualFS, options: { cwd?: string } & RegistryOptions = {}) {
    this.vfs = vfs;
    this.registry = new Registry(options);
    this.cwd = options.cwd || '/';
  }

  /**
   * Install a package and its dependencies
   */
  async install(
    packageSpec: string,
    options: InstallOptions = {}
  ): Promise<InstallResult> {
    const { onProgress } = options;

    // Parse package spec (name@version)
    const { name, version } = parsePackageSpec(packageSpec);

    onProgress?.(`Resolving ${name}@${version || 'latest'}...`);

    // Resolve dependencies
    const resolved = await resolveDependencies(name, version || 'latest', {
      registry: this.registry,
      includeDev: options.includeDev,
      includeOptional: options.includeOptional,
      onProgress,
    });

    // Install all resolved packages
    const added = await this.installResolved(resolved, options);

    // Update package.json if save option is set
    if (options.save || options.saveDev) {
      const pkgToAdd = resolved.get(name);
      if (pkgToAdd) {
        await this.updatePackageJson(
          name,
          `^${pkgToAdd.version}`,
          options.saveDev || false
        );
      }
    }

    onProgress?.(`Installed ${resolved.size} packages`);

    return { installed: resolved, added };
  }

  /**
   * Install all dependencies from package.json
   */
  async installFromPackageJson(options: InstallOptions = {}): Promise<InstallResult> {
    const { onProgress } = options;

    const pkgJsonPath = path.join(this.cwd, 'package.json');

    if (!this.vfs.existsSync(pkgJsonPath)) {
      throw new Error('No package.json found');
    }

    const pkgJson = JSON.parse(this.vfs.readFileSync(pkgJsonPath, 'utf8'));

    onProgress?.('Resolving dependencies...');

    // Resolve all dependencies
    const resolved = await resolveFromPackageJson(pkgJson, {
      registry: this.registry,
      includeDev: options.includeDev,
      includeOptional: options.includeOptional,
      onProgress,
    });

    // Install all resolved packages
    const added = await this.installResolved(resolved, options);

    onProgress?.(`Installed ${resolved.size} packages`);

    return { installed: resolved, added };
  }

  /**
   * Install resolved packages to node_modules
   */
  private async installResolved(
    resolved: Map<string, ResolvedPackage>,
    options: InstallOptions
  ): Promise<string[]> {
    const { onProgress } = options;
    const added: string[] = [];

    // Ensure node_modules exists
    const nodeModulesPath = path.join(this.cwd, 'node_modules');
    this.vfs.mkdirSync(nodeModulesPath, { recursive: true });

    // Fail fast on unsupported vite@8+ before downloading anything.
    for (const [name, pkg] of resolved) {
      if (name === 'vite') {
        assertViteSupported(pkg.version);
      }
    }

    // Filter packages that need to be installed
    const toInstall: Array<{ name: string; pkg: ResolvedPackage; pkgPath: string }> = [];

    for (const [name, pkg] of resolved) {
      const pkgPath = path.join(nodeModulesPath, name);

      // Skip if already installed with same version
      const existingPkgJson = path.join(pkgPath, 'package.json');
      if (this.vfs.existsSync(existingPkgJson)) {
        try {
          const existing = JSON.parse(
            this.vfs.readFileSync(existingPkgJson, 'utf8')
          );
          if (existing.version === pkg.version) {
            onProgress?.(`Skipping ${name}@${pkg.version} (already installed)`);
            continue;
          }
        } catch {
          // Continue with installation if package.json is invalid
        }
      }

      toInstall.push({ name, pkg, pkgPath });
    }

    // Initialize transformer if transform option is enabled (default: true)
    const shouldTransform = options.transform !== false;
    if (shouldTransform && !isTransformerReady()) {
      onProgress?.('Initializing ESM transformer...');
      await initTransformer();
    }

    // Install packages in parallel (limit concurrency to avoid overwhelming the browser)
    const CONCURRENCY = 6;
    onProgress?.(`Installing ${toInstall.length} packages...`);

    for (let i = 0; i < toInstall.length; i += CONCURRENCY) {
      const batch = toInstall.slice(i, i + CONCURRENCY);

      await Promise.all(
        batch.map(async ({ name, pkg, pkgPath }) => {
          onProgress?.(`  Downloading ${name}@${pkg.version}...`);

          // Download and extract tarball
          await downloadAndExtract(pkg.tarballUrl, this.vfs, pkgPath, {
            stripComponents: 1, // Strip "package/" prefix
          });

          // Read package.json once (reused below for the transform decision and
          // bin-stub creation).
          let pkgJson: PackageJson | null = null;
          const pkgJsonPath = path.join(pkgPath, 'package.json');
          if (this.vfs.existsSync(pkgJsonPath)) {
            try {
              pkgJson = JSON.parse(this.vfs.readFileSync(pkgJsonPath, 'utf8')) as PackageJson;
            } catch {
              pkgJson = null;
            }
          }

          // Transform ESM to CJS
          if (shouldTransform) {
            // Keep ESM-only framework runtime packages as ESM so browser dev
            // servers (real Vite) can serve them with real named exports.
            // require() of these still works — the runtime transforms ESM→CJS
            // at load time. Dual packages (separate ESM+CJS entries) are also
            // kept as ESM — their .cjs entry already serves require().
            const isEsmOnlyRuntime = name === 'vue' || name.startsWith('@vue/');
            const isDual = !!pkgJson && isDualPackage(pkgJson);
            if (!isEsmOnlyRuntime && !isDual) {
              try {
                const count = await transformPackage(this.vfs, pkgPath, onProgress);
                if (count > 0) {
                  onProgress?.(`  Transformed ${count} files in ${name}`);
                }
              } catch (transformError) {
                onProgress?.(`  Warning: Transform failed for ${name}: ${transformError}`);
              }
            }
          }

          // Create bin stubs in /node_modules/.bin/
          try {
            if (pkgJson) {
              const binEntries = normalizeBin(name, pkgJson.bin as Record<string, string> | string | undefined);
              const binDir = path.join(nodeModulesPath, '.bin');
              for (const [cmdName, entryPath] of Object.entries(binEntries)) {
                this.vfs.mkdirSync(binDir, { recursive: true });
                const targetPath = path.join(pkgPath, entryPath);
                this.vfs.writeFileSync(
                  path.join(binDir, cmdName),
                  `node "${targetPath}" "$@"\n`
                );
              }
            }
          } catch {
            // Non-critical — skip if bin stub creation fails
          }

          added.push(name);
        })
      );
    }

    // Create .package-lock.json for tracking
    await this.writeLockfile(resolved);

    return added;
  }

  /**
   * Write lockfile with resolved versions
   */
  private async writeLockfile(
    resolved: Map<string, ResolvedPackage>
  ): Promise<void> {
    const lockfile: Record<string, { version: string; resolved: string }> = {};

    for (const [name, pkg] of resolved) {
      lockfile[name] = {
        version: pkg.version,
        resolved: pkg.tarballUrl,
      };
    }

    const lockfilePath = path.join(this.cwd, 'node_modules', '.package-lock.json');
    this.vfs.writeFileSync(lockfilePath, JSON.stringify(lockfile, null, 2));
  }

  /**
   * Update package.json with new dependency
   */
  private async updatePackageJson(
    packageName: string,
    version: string,
    isDev: boolean
  ): Promise<void> {
    const pkgJsonPath = path.join(this.cwd, 'package.json');

    let pkgJson: Record<string, unknown> = {};

    if (this.vfs.existsSync(pkgJsonPath)) {
      pkgJson = JSON.parse(this.vfs.readFileSync(pkgJsonPath, 'utf8'));
    }

    const field = isDev ? 'devDependencies' : 'dependencies';

    if (!pkgJson[field]) {
      pkgJson[field] = {};
    }

    (pkgJson[field] as Record<string, string>)[packageName] = version;

    this.vfs.writeFileSync(pkgJsonPath, JSON.stringify(pkgJson, null, 2));
  }

  /**
   * List installed packages
   */
  list(): Record<string, string> {
    const nodeModulesPath = path.join(this.cwd, 'node_modules');

    if (!this.vfs.existsSync(nodeModulesPath)) {
      return {};
    }

    const packages: Record<string, string> = {};
    const entries = this.vfs.readdirSync(nodeModulesPath);

    for (const entry of entries) {
      // Skip hidden files and non-package entries
      if (entry.startsWith('.')) continue;

      // Handle scoped packages (@org/pkg)
      if (entry.startsWith('@')) {
        const scopePath = path.join(nodeModulesPath, entry);
        const scopedPkgs = this.vfs.readdirSync(scopePath);

        for (const scopedPkg of scopedPkgs) {
          const pkgJsonPath = path.join(scopePath, scopedPkg, 'package.json');
          if (this.vfs.existsSync(pkgJsonPath)) {
            const pkgJson = JSON.parse(this.vfs.readFileSync(pkgJsonPath, 'utf8'));
            packages[`${entry}/${scopedPkg}`] = pkgJson.version;
          }
        }
      } else {
        const pkgJsonPath = path.join(nodeModulesPath, entry, 'package.json');
        if (this.vfs.existsSync(pkgJsonPath)) {
          const pkgJson = JSON.parse(this.vfs.readFileSync(pkgJsonPath, 'utf8'));
          packages[entry] = pkgJson.version;
        }
      }
    }

    return packages;
  }
}

/**
 * Parse a package specifier into name and version
 * Examples: "express", "express@4.18.2", "@types/node@18"
 */
function parsePackageSpec(spec: string): { name: string; version?: string } {
  // Handle scoped packages
  if (spec.startsWith('@')) {
    const slashIndex = spec.indexOf('/');
    if (slashIndex === -1) {
      throw new Error(`Invalid package spec: ${spec}`);
    }

    const afterSlash = spec.slice(slashIndex + 1);
    const atIndex = afterSlash.indexOf('@');

    if (atIndex === -1) {
      return { name: spec };
    }

    return {
      name: spec.slice(0, slashIndex + 1 + atIndex),
      version: afterSlash.slice(atIndex + 1),
    };
  }

  // Regular packages
  const atIndex = spec.indexOf('@');
  if (atIndex === -1) {
    return { name: spec };
  }

  return {
    name: spec.slice(0, atIndex),
    version: spec.slice(atIndex + 1),
  };
}

// Convenience function for quick installs
export async function install(
  packageSpec: string,
  vfs: VirtualFS,
  options?: InstallOptions
): Promise<InstallResult> {
  const pm = new PackageManager(vfs);
  return pm.install(packageSpec, options);
}

// Re-export types and modules
export { Registry } from './registry';
export type { RegistryOptions, PackageVersion, PackageManifest } from './registry';
export type { ResolvedPackage, ResolveOptions } from './resolver';
export type { ExtractOptions } from './tarball';
export { parsePackageSpec };
